# Week 2: Intermediate Object-Oriented Programming

## Monday: Mini-Projects

#### Readings
- None

## Tuesday: Class Interactions

#### Readings
- None

## Wednesday: I/O

#### Readings
- [I/O][io-reading]

[io-reading]: ./w2d3/readings/io.md

## Thursday: Tic Tac Toe

#### Readings
- Included in exercises

## Friday: Review

#### Exercises
- Refactor your old work and work on bonus problems.

## Bonus
- [CodeEval][code-eval] problems (requires git login)

[code-eval]: http://www.codeeval.com/
