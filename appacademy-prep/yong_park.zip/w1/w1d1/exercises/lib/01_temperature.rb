def ftoc(temp)
  celc = (temp - 32) * (5.0/9)
  celc
end

def ctof(temp)
  fahr = (temp * 1.8) + 32
  fahr
end