def hello
  "Hello!"
end

def greet(name)
  "Hello, #{name}!"
end
